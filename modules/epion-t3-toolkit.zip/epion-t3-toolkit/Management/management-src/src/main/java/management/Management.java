package management;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Management {
	
	private String basePath = "C:\\et3";
	
	private int history = 10;
	
	private int resultCode = -1;
	
	private String target = null;
	
	public Management(String _basePath, int _history, int _resultCode, String _target) {
		if (_basePath != null) {
		    basePath = _basePath;
		}
		if (_history > 0) {
			history = _history;
		}
		resultCode = _resultCode;
		target = _target;
	}

	public void execute() {
		File dir = new File(basePath);
		
		File[] list = dir.listFiles();
		
		if(list == null) {
			return;
		}
		
		List<String> projectList = new ArrayList<>();
		
		String replacePath = basePath.replace("/", "\\") + "\\";
		for (File file : list) {
			if (file.isDirectory()) {
				String projectName = file.toString().replace(replacePath, "");
				projectList.add(projectName);
				
				if (projectName != null && projectName.equals(target)) {
					cleanResult(file);
				}
			}
		}
		
		String projectListHtml = createProjectListHtml(projectList);
		chengeFirstIndexHtml(projectListHtml);
	}
	
	private String createProjectListHtml(List<String> projectList) {
		StringBuilder builder = new StringBuilder();
		
		for (String project : projectList) {
			builder.append("          <tr><td><a href=\"./");
			builder.append(project);
			builder.append("/index.html\">");
			
			builder.append(project);
			builder.append("</a></td></tr>\r\n");
		}
		
		return builder.toString();
	}
	
	private void chengeFirstIndexHtml(String projectListHtml) {
		File indexHtml = new File(basePath + "\\index.html");
		
		try {
			InputStream is = ClassLoader.getSystemResourceAsStream("first-index.html");
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			String string = reader.readLine();
			StringBuilder builder = new StringBuilder();
	        while (string != null){
	            builder.append(string + System.getProperty("line.separator"));
	            string = reader.readLine();
	        }
	        
	        String allText = builder.toString();
	        
	        String tbody = "<tbody>\r\n" + projectListHtml + "        </tbody>";
	        
	        Pattern pattern = Pattern.compile("<tbody>.+?</tbody>", Pattern.DOTALL);
	        Matcher matcher = pattern.matcher(allText);
	        String result = matcher.replaceAll(tbody);
	        
	        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(indexHtml)));
	        
	        pw.println(result);
	        pw.close();
	        reader.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	private void cleanResult(File dir) {
		File[] list = dir.listFiles();
		
		List<String> dirNameList = new ArrayList<>();
		
		String replacePath = dir.toString() + "\\";
		for (File file : list) {
			if (file.isDirectory()) {
				dirNameList.add(file.toString().replace(replacePath, ""));
			}
		}
		
		Collections.sort(dirNameList, Comparator.reverseOrder());
		
		int loopCount = 0;
		
		List<String> deleteList = new ArrayList<>();
		for (String resultDir: dirNameList) {		
			if (loopCount < history) {
				loopCount++;
				continue;
			}
			DirectoryDelete.execute(new File(dir.toString() + "\\" + resultDir));
			deleteList.add(resultDir);
		}
			
		
		File indexHtml = new File(dir + "\\index.html");
		String newResultHtml = createNewResultHtml(dirNameList.get(0));

		replacePath = basePath + "\\";
		changeIndexHtml(indexHtml, newResultHtml, deleteList, dir.toString().replace(replacePath, ""));
	}
	
	private String createNewResultHtml(String newResult) {
		StringBuilder builder = new StringBuilder();
		
		builder.append("          <tr><td><a href=\"./");
		builder.append(newResult);
		builder.append("/report.html\">");
		
		String[] dateTime = newResult.split("_", 0);
		String date = dateTime[0];
		String time = dateTime[1];
		
		builder.append(date.substring(0,4));
		builder.append("�N");
		builder.append(date.substring(4,6));
		builder.append("��");
		builder.append(date.substring(6,8));
		builder.append("��   ");
		builder.append(time.substring(0,2));
		builder.append("��");
		builder.append(time.substring(2,4));
		builder.append("��");
		builder.append("</a></td>");
		
		return builder.toString();
	}
	
	private void changeIndexHtml(File indexHtml, String newResultHtml, List<String> deleteResultList, String projectName) {

		try {
			BufferedReader reader;
			if (!indexHtml.exists()) {
			    InputStream is = ClassLoader.getSystemResourceAsStream("index.html");
			    reader = new BufferedReader(new InputStreamReader(is));
			} else {
				reader = new BufferedReader(new FileReader(indexHtml));
			}
			String string = reader.readLine();
			StringBuilder builder = new StringBuilder();
	        while (string != null) {
	            builder.append(string + System.getProperty("line.separator"));
	            string = reader.readLine();
	        }
	        
	        String allText = builder.toString();
	        
	        for (String deleteResult: deleteResultList) {
	        	allText = Pattern.compile(".+?<a href=\"./" + deleteResult + "/report.html\">.+?</tr>\r\n").matcher(allText).replaceAll("");
	        }
	               
	        if (!allText.contains(newResultHtml)) {
	        	String newBody = "</th></tr>\r\n" + newResultHtml + ResultCode.codeToHtml(resultCode) + "</tr>";
	        	allText = allText.replaceAll("</th></tr>", newBody);
	        }
	        
	        if (!indexHtml.exists()) {
	            String h4 = "<h4>" + projectName + " - Test Result</h4>";
	            Pattern projectNamepattern = Pattern.compile("<h4>.+?</h4>", Pattern.DOTALL);
	            Matcher projectNameMattcher = projectNamepattern.matcher(allText);
	            allText = projectNameMattcher.replaceAll(h4);
	        }
	        
	        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(indexHtml)));
	        
	        pw.println(allText);
	        pw.close();
	        reader.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
}
