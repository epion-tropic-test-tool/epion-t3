package management;

public class Main {

	public static void main(String[] args) {
		int history = 0;
		int resultCode = -1;
		String path = null;
		String target = null;
		for (int i=0; i<args.length; ++i) {
            if ("-history".equals(args[i]) || "-h".equals(args[i])) {
            	history = Integer.parseInt(args[++i]);
            } else if ("-path".equals(args[i]) || "-p".equals(args[i])) {
            	path = args[++i];
            } else if ("-code".equals(args[i]) || "-c".equals(args[i])) {
            	resultCode = Integer.parseInt(args[++i]);
            } else if ("-target".equals(args[i]) || "-t".equals(args[i])) {
            	target = args[++i];
            } else {
            	System.err.println("�����w��̌��F���m�̈������w�肳��܂���");
            	return;
            }
        }
		if (target == null) {
			System.err.println("-target�̎w�肪����܂���");
			return;
		}
		
		Management management = new Management(path, history, resultCode, target);
		management.execute();
	}

}
