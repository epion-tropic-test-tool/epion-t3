package management;

public class ResultCode {

	public static String codeToHtml(int exitCode) {
		String html = "";
		
		switch(exitCode) {
		    case 0:
			    html = "<td class=\"table-success\">SUCCESS</td>";
			    break;
		    case 1:
		    	html = "<td class=\"table-danger\">SCENARIO_ERROR</td>";
		    	break;
		    case 2:
		    	html = "<td class=\"table-danger\">ASSERT_ERROR</td>";
		    	break;
		    case 9:
		    	html = "<td class=\"table-danger\">ERROR</td>";
		    	break;
		    case 100:
		    	html = "<td class=\"table-danger\">UNASSIGNED</td>";
		    	break;
		    default:
		    	break;
		}
		
		return html;
	}
}
