#!/bin/bash
java -jar `dirname ${0}`/management.jar -path C:\et3 -history 10 -code $1 -target $2