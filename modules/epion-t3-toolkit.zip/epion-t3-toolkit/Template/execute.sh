#!/bin/sh
OUTPUT_BASE_PATH=C:\/et3

PROJECT_NAME=$1
SCENARIO_NAME=$2

DATE = `date '+%Y%m%d'`
TIME = `date '+%H%M%S'`
DIR_NAME = "${DATE}_${TIME}"
mkdir ${OUTPUT_BASE_PATH}/${PROJECT_NAME}/${DIR_NAME}

java -jar ../../userContent/et3/epion-t3.jar -v v1.0 -m test -p develop -t ${SCENARIO_NAME} -s ./ -o ${OUTPUT_BASE_PATH}/${PROJECT_NAME}/${DIR_NAME}