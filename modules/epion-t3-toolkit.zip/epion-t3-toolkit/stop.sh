cd ./Tomcat/apache-tomcat-9.0.16/bin
shutdown.sh &
cd ../../../Nginx/nginx-1.15.9
nginx -s quit &