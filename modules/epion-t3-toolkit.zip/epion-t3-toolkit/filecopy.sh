cp -r -f ./et3 ~/.jenkins/userContent/et3
cp -r -f ./Management ~/.jenkins/userContent/Management